<?php

// For customs Twig Filters  in Lib/CakePhpTwig
require_once 'CakePhpTwig_Autoloader.php';
CakePhpTwig_Autoloader::register();

