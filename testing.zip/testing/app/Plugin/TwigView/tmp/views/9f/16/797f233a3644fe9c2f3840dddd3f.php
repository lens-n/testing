<?php

/* Errors/missing_controller.htm */
class __TwigTemplate_9f16797f233a3644fe9c2f3840dddd3f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "Errors/missing_controller.htm";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
