<?php

/* Reports/index.htm */
class __TwigTemplate_9f134d51e11cf28137c38048d4f43c18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Отчеты:</h2>
<table class=\"table table-striped\">
    <tr>
        <th>ID</th>
        <th>Фамилия</th>
        <th>Имя</th>
        <th>Название теста</th>
        <th> Оценка</th>
        <th> ECTS</th>
        <th></th>
    </tr>
 ";
        // line 12
        if (isset($context["reports"])) { $_reports_ = $context["reports"]; } else { $_reports_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_reports_);
        foreach ($context['_seq'] as $context["_key"] => $context["report"]) {
            // line 13
            echo "     <tr>
         <td>";
            // line 14
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_report_, "Report"), "id");
            echo "</td>
         <td>";
            // line 15
            if (isset($context["students"])) { $_students_ = $context["students"]; } else { $_students_ = null; }
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_students_, $this->getAttribute($this->getAttribute($_report_, "Report"), "students_id"), array(), "array"), "sname", array(), "array");
            echo "</td>
         <td>";
            // line 16
            if (isset($context["students"])) { $_students_ = $context["students"]; } else { $_students_ = null; }
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_students_, $this->getAttribute($this->getAttribute($_report_, "Report"), "students_id"), array(), "array"), "fname", array(), "array");
            echo "</td>
         <td>";
            // line 17
            if (isset($context["tests"])) { $_tests_ = $context["tests"]; } else { $_tests_ = null; }
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_tests_, $this->getAttribute($this->getAttribute($_report_, "Report"), "tests_id"), array(), "array"), "title", array(), "array");
            echo "</td>
         <td> ";
            // line 18
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_report_, "Report"), "mark");
            echo "     </td>
         ";
            // line 19
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            if (($this->getAttribute($this->getAttribute($_report_, "Report"), "mark") > 89)) {
                // line 20
                echo "             <td>  A  </td>
         ";
            } elseif (($this->getAttribute($this->getAttribute($_report_, "Report"), "mark") > 79)) {
                // line 22
                echo "
             <td>  B </td>
         ";
            } elseif (($this->getAttribute($this->getAttribute($_report_, "Report"), "mark") > 64)) {
                // line 25
                echo "
             <td>  C </td>
         ";
            } elseif (($this->getAttribute($this->getAttribute($_report_, "Report"), "mark") > 54)) {
                // line 28
                echo "
             <td>  D </td>
         ";
            } elseif (($this->getAttribute($this->getAttribute($_report_, "Report"), "mark") > 49)) {
                // line 31
                echo "
             <td>  E </td>
         ";
            } elseif (($this->getAttribute($this->getAttribute($_report_, "Report"), "mark") > 34)) {
                // line 34
                echo "
             <td>  FX</td>
         ";
            } else {
                // line 37
                echo "
             <td>  F</td>
         ";
            }
            // line 40
            echo "


         <td><a href=\"/reports/view/ ";
            // line 43
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_report_, "Report"), "id");
            echo "\">посмотреть</a></td>
     </tr>


    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['report'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 48
        echo "

</table>















";
    }

    public function getTemplateName()
    {
        return "Reports/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 48,  110 => 43,  105 => 40,  100 => 37,  95 => 34,  90 => 31,  85 => 28,  80 => 25,  75 => 22,  71 => 20,  68 => 19,  63 => 18,  57 => 17,  51 => 16,  45 => 15,  40 => 14,  37 => 13,  32 => 12,  19 => 1,);
    }
}
