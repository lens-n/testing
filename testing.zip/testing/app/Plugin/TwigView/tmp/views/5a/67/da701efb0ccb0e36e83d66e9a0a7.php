<?php

/* Courses/index.htm */
class __TwigTemplate_5a67da701efb0ccb0e36e83d66e9a0a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Список курсов:</h2>
<table class=\"table table-striped\" style=\"width: 40%; text-align: center;\">
    <tr>
        <th style=\"text-align: center;\">Название</th>
        <th></th>
        <th></th>
    </tr>
    ";
        // line 8
        if (isset($context["courses"])) { $_courses_ = $context["courses"]; } else { $_courses_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_courses_);
        foreach ($context['_seq'] as $context["_key"] => $context["cours"]) {
            // line 9
            echo "        <tr>
            <td style=\"text-align: center;\">  ";
            // line 10
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "title");
            echo " курс </td>
            <td><a href=\"/courses/edit/";
            // line 11
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "id");
            echo "\">изменить</a></td>
            <td><a href=\"/courses/edit/";
            // line 12
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "id");
            echo "\">x</a></td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cours'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 15
        echo "
</table>

<a href=\"/courses/add\">Добавить</a>















";
    }

    public function getTemplateName()
    {
        return "Courses/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 15,  46 => 12,  41 => 11,  36 => 10,  33 => 9,  28 => 8,  19 => 1,);
    }
}
