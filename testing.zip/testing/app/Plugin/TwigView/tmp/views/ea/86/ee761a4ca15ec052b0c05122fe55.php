<?php

/* Elements/footer-front.htm */
class __TwigTemplate_ea86ee761a4ca15ec052b0c05122fe55 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"footermainPan\">
    <div id=\"footerPan\">

        <p class=\"copyright\">Testing.onmu.ua. All right reserved.</p>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "Elements/footer-front.htm";
    }

    public function getDebugInfo()
    {
        return array (  60 => 28,  51 => 23,  46 => 22,  25 => 5,  19 => 1,);
    }
}
