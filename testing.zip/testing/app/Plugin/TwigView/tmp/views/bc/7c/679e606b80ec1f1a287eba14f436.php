<?php

/* Tests/stop.htm */
class __TwigTemplate_bc7c679e606b80ec1f1a287eba14f436 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Результаты:</h2>
";
        // line 2
        if (isset($context["themes_marks"])) { $_themes_marks_ = $context["themes_marks"]; } else { $_themes_marks_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_themes_marks_);
        foreach ($context['_seq'] as $context["_key"] => $context["theme"]) {
            // line 3
            echo "    Ваша  оценка по теме <strong>\"";
            if (isset($context["themes"])) { $_themes_ = $context["themes"]; } else { $_themes_ = null; }
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_themes_, $this->getAttribute($_theme_, "id"), array(), "array"), "title", array(), "array");
            echo "\" : </strong> <strong>";
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($_theme_, "mark");
            echo " балов </strong><br><br>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['theme'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 5
        echo "

Ваша оценка за весь тест: <strong>";
        // line 7
        if (isset($context["mark"])) { $_mark_ = $context["mark"]; } else { $_mark_ = null; }
        echo $_mark_;
        echo " балов</strong>











";
    }

    public function getTemplateName()
    {
        return "Tests/stop.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 7,  41 => 5,  27 => 3,  22 => 2,  19 => 1,);
    }
}
