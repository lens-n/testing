<?php

/* Groups/index.htm */
class __TwigTemplate_74953cf758bc2410a0985bb4eb861ef9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Группы:</h2>
";
        // line 2
        if (isset($context["groups"])) { $_groups_ = $context["groups"]; } else { $_groups_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_groups_);
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 3
            echo "    ";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            $context["id"] = $this->getAttribute($this->getAttribute($_group_, "Group"), "faculties_id");
            // line 4
            echo "    ";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            $context["id_cours"] = $this->getAttribute($this->getAttribute($_group_, "Group"), "cours_id");
            // line 5
            echo "
    ";
            // line 6
            if (isset($context["id_cours"])) { $_id_cours_ = $context["id_cours"]; } else { $_id_cours_ = null; }
            if (isset($context["id_old_cours"])) { $_id_old_cours_ = $context["id_old_cours"]; } else { $_id_old_cours_ = null; }
            if (($_id_cours_ != $_id_old_cours_)) {
                // line 7
                echo "        <h2> Курс: ";
                if (isset($context["courses"])) { $_courses_ = $context["courses"]; } else { $_courses_ = null; }
                if (isset($context["id_cours"])) { $_id_cours_ = $context["id_cours"]; } else { $_id_cours_ = null; }
                echo $this->getAttribute($this->getAttribute($_courses_, $_id_cours_, array(), "array"), "title", array(), "array");
                echo "</h2>
    ";
            }
            // line 9
            echo "
    ";
            // line 10
            if (isset($context["id"])) { $_id_ = $context["id"]; } else { $_id_ = null; }
            if (isset($context["id_old"])) { $_id_old_ = $context["id_old"]; } else { $_id_old_ = null; }
            if (($_id_ != $_id_old_)) {
                // line 11
                echo "       <h3> Факультет: ";
                if (isset($context["faculties"])) { $_faculties_ = $context["faculties"]; } else { $_faculties_ = null; }
                if (isset($context["id"])) { $_id_ = $context["id"]; } else { $_id_ = null; }
                echo $this->getAttribute($this->getAttribute($_faculties_, $_id_, array(), "array"), "title", array(), "array");
                echo "</h3>
    ";
            }
            // line 13
            echo "
<a href=\"/groups/edit/";
            // line 14
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            echo $this->getAttribute($this->getAttribute($_group_, "Group"), "id");
            echo "\"> Группа ";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            echo $this->getAttribute($this->getAttribute($_group_, "Group"), "title");
            echo "</a><br/>
    ";
            // line 15
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            $context["id_old"] = $this->getAttribute($this->getAttribute($_group_, "Group"), "faculties_id");
            // line 16
            echo "    ";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            $context["id_old_cours"] = $this->getAttribute($this->getAttribute($_group_, "Group"), "cours_id");
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 18
        echo "<br/>
<a href=\"/groups/add\">Добавить</a>














";
    }

    public function getTemplateName()
    {
        return "Groups/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 18,  79 => 16,  76 => 15,  68 => 14,  65 => 13,  57 => 11,  53 => 10,  50 => 9,  42 => 7,  38 => 6,  35 => 5,  31 => 4,  27 => 3,  22 => 2,  19 => 1,);
    }
}
