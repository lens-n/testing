<?php

/* Themes/index.htm */
class __TwigTemplate_e61f3000611f79abb6e411ca69e3e09a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Темы:</h2>
<table class=\"table table-striped\">
    <tr>
        <th>Ид</th>
        <th>Тема</th>
        <th>Предмет</th>
        <th></th>
        <th></th>
    </tr>
";
        // line 10
        if (isset($context["themes"])) { $_themes_ = $context["themes"]; } else { $_themes_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_themes_);
        foreach ($context['_seq'] as $context["_key"] => $context["theme"]) {
            // line 11
            echo "    <tr>
        <td>";
            // line 12
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_theme_, "Theme"), "id");
            echo "</td>
        <td>";
            // line 13
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_theme_, "Theme"), "title");
            echo "</td>
        <td>";
            // line 14
            if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_subjects_, $this->getAttribute($this->getAttribute($_theme_, "Theme"), "subjects_id"), array(), "array"), "title", array(), "array");
            echo " </td>
        <td><a href=\"/themes/edit/";
            // line 15
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_theme_, "Theme"), "id");
            echo "\">изменить</a></td>
        <td > <a style=\"color:#f00\" href=\"/themes/del/";
            // line 16
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_theme_, "Theme"), "id");
            echo "\">x</a></td>
    </tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['theme'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 19
        echo "</table>
<br/>
<a href=\"/themes/add\">Добавить</a>









";
    }

    public function getTemplateName()
    {
        return "Themes/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 19,  59 => 16,  54 => 15,  48 => 14,  43 => 13,  38 => 12,  35 => 11,  30 => 10,  19 => 1,);
    }
}
