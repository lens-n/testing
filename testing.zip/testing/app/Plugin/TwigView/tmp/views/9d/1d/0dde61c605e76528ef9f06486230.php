<?php

/* Students/index.htm */
class __TwigTemplate_9d1d0dde61c605e76528ef9f06486230 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Список студентов</h2>
<table class=\"table table-striped\"  >
";
        // line 3
        if (isset($context["students"])) { $_students_ = $context["students"]; } else { $_students_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_students_);
        foreach ($context['_seq'] as $context["_key"] => $context["student"]) {
            // line 4
            echo "    <tr>
        <td>";
            // line 5
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "id");
            echo "</td>
        <td>";
            // line 6
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "fname");
            echo "</td>
        <td> ";
            // line 7
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "sname");
            echo "</td>
        <td>";
            // line 8
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "pname");
            echo "</td>
        <td><a href=\"/students/edit/";
            // line 9
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "id");
            echo "\">изменить</a></td>
        <td><a href=\"/students/del/";
            // line 10
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "id");
            echo "\" style=\"color: red\">x</a></td>

    </tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['student'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 14
        echo "</table>
<a href=\"/students/add\">Добавить</a>













";
    }

    public function getTemplateName()
    {
        return "Students/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 14,  56 => 10,  51 => 9,  46 => 8,  41 => 7,  36 => 6,  31 => 5,  28 => 4,  23 => 3,  19 => 1,);
    }
}
