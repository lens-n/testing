<?php

/* Questions/index.htm */
class __TwigTemplate_a9b1916017d5831e4e5e0ed9aa04822a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Вопросы:</h2>
";
        // line 2
        $context["subj"] = "";
        // line 3
        $context["theme"] = "";
        // line 4
        if (isset($context["questions"])) { $_questions_ = $context["questions"]; } else { $_questions_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_questions_);
        foreach ($context['_seq'] as $context["_key"] => $context["question"]) {
            // line 5
            echo "
    ";
            // line 6
            if (isset($context["subj"])) { $_subj_ = $context["subj"]; } else { $_subj_ = null; }
            if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
            if (($_subj_ != $this->getAttribute($_question_, "subjects_id"))) {
                // line 7
                echo "        <h2>";
                if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($this->getAttribute($_subjects_, $this->getAttribute($_question_, "subjects_id"), array(), "array"), "title", array(), "array");
                echo "</h2>
        ";
                // line 8
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                $context["subj"] = $this->getAttribute($_question_, "subjects_id");
                // line 9
                echo "    ";
            }
            // line 10
            echo "    ";
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
            if (($_theme_ != $this->getAttribute($_question_, "themes_id"))) {
                // line 11
                echo "        <h4>";
                if (isset($context["themes"])) { $_themes_ = $context["themes"]; } else { $_themes_ = null; }
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($this->getAttribute($_themes_, $this->getAttribute($_question_, "themes_id"), array(), "array"), "title", array(), "array");
                echo "</h4>
        ";
                // line 12
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                $context["theme"] = $this->getAttribute($_question_, "themes_id");
                // line 13
                echo "    ";
            }
            // line 14
            echo "    ";
            if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
            if (($this->getAttribute($_question_, "priority") == 0)) {
                // line 15
                echo "    ";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "text");
                echo "  <a href=\"/questions/edit/";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\">изменить</a>  <a href=\"/questions/del/";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\">x</a><br/>
    ";
            } else {
                // line 17
                echo "        <div style=\"margin-left: 50px; width:200px; float:left\"> -->";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "text");
                echo "</div>  <a href=\"/questions/edit/";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\">изменить</a>  <a href=\"/questions/del/";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\">x</a><br/>
    ";
            }
            // line 19
            echo "
    <br>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['question'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 22
        echo "
<br/>
<a href=\"/questions/add\">Добавить</a>















";
    }

    public function getTemplateName()
    {
        return "Questions/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 22,  99 => 19,  86 => 17,  73 => 15,  69 => 14,  66 => 13,  63 => 12,  56 => 11,  51 => 10,  48 => 9,  45 => 8,  38 => 7,  34 => 6,  31 => 5,  26 => 4,  24 => 3,  22 => 2,  19 => 1,);
    }
}
