<?php

/* Admin/login.htm */
class __TwigTemplate_e71214548d964574df849d40f358330d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "

<form class=\"form-horizontal\" method=\"post\" action=\"/admin/login\">
    <legend>Форма авторизации:</legend>
    <div class=\"control-group\">
        <label class=\"control-label\" for=\"inputEmail\">Логин</label>
        <div class=\"controls\">
            <input type=\"text\" id=\"inputLogin\" name=\"login\" placeholder=\"Логин\">
        </div>
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\" for=\"inputPassword\">Пароль</label>
        <div class=\"controls\">
            <input type=\"password\" id=\"inputPassword\" name=\"password\" placeholder=\"Пароль\">
        </div>
    </div>
    <div class=\"control-group\">
        <div class=\"controls\">

            <button type=\"submit\" class=\"btn\">Войти</button>
        </div>
    </div>
</form>";
    }

    public function getTemplateName()
    {
        return "Admin/login.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
