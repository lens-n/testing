<?php

/* Elements/footer.htm */
class __TwigTemplate_100e9a323d94ff9a7c14921a0e1b0bc7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"footermainPan\">
    <div id=\"footerPan\">
";
        // line 16
        echo "        <p class=\"copyright\">Testing.onmu.ua. All right reserved.</p>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "Elements/footer.htm";
    }

    public function getDebugInfo()
    {
        return array (  23 => 16,  19 => 1,);
    }
}
