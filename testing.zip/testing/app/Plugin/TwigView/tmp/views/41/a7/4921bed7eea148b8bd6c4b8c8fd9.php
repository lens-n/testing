<?php

/* Tests/index.htm */
class __TwigTemplate_41a74921bed7eea148b8bd6c4b8c8fd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Тесты:</h2>
<table  class=\"table table-striped\"   >
    <tr>
        <td>Название</td>
        <td>Предмет</td>
        <td>Факультет</td>
        <td>Курс</td>
        <td>Группа</td>
        <td id=\"error\"></td>
        <td></td>
        <td></td>
    </tr>
";
        // line 13
        if (isset($context["tests"])) { $_tests_ = $context["tests"]; } else { $_tests_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_tests_);
        foreach ($context['_seq'] as $context["_key"] => $context["test"]) {
            // line 14
            echo "    <tr>
        <td>";
            // line 15
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_test_, "Test"), "title");
            echo "</td>
        <td>";
            // line 16
            if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_subjects_, $this->getAttribute($this->getAttribute($_test_, "Test"), "subject_id"), array(), "array"), "title", array(), "array");
            echo " </td>
        <td>";
            // line 17
            if (isset($context["faculties"])) { $_faculties_ = $context["faculties"]; } else { $_faculties_ = null; }
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculties_, $this->getAttribute($this->getAttribute($_test_, "Test"), "faculty_id"), array(), "array"), "title", array(), "array");
            echo " </td>
        <td>";
            // line 18
            if (isset($context["courses"])) { $_courses_ = $context["courses"]; } else { $_courses_ = null; }
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_courses_, $this->getAttribute($this->getAttribute($_test_, "Test"), "cours_id"), array(), "array"), "title", array(), "array");
            echo " </td>
        <td>";
            // line 19
            if (isset($context["groups"])) { $_groups_ = $context["groups"]; } else { $_groups_ = null; }
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_groups_, $this->getAttribute($this->getAttribute($_test_, "Test"), "group_id"), array(), "array"), "title", array(), "array");
            echo " </td>
        <td><a onclick=\"TestActive(";
            // line 20
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_test_, "Test"), "id");
            echo ")\" class=\"active\" href=\"#\" >";
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            if (($this->getAttribute($this->getAttribute($_test_, "Test"), "active") == 0)) {
                echo "Активировать";
            } else {
                echo "Деактивировать";
            }
            echo "</a></td>
        <td><a href=\"/tests/edit/";
            // line 21
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_test_, "Test"), "id");
            echo "\">изменить</a></td>
        <td> <a href=\"/tests/del/";
            // line 22
            if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
            echo $this->getAttribute($this->getAttribute($_test_, "Test"), "id");
            echo "\">x</a></td>
    </tr>

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['test'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 26
        echo "</table>
<a href=\"/tests/add\">Добавить</a>

<script type=\"text/javascript\">
    function TestActive(id){

    \$.ajax({
        type: \"POST\",
        url: \"/tests/active/\"+id,
        success: function(data){
            if( data ==  'Тест активирован!'){
                \$('.active').html( 'Деактивировать' );
            }
            else{
                \$('.active').html( 'Активировать' );
            }
            \$('#alert').html( data );



        }
    });
    }

</script>









";
    }

    public function getTemplateName()
    {
        return "Tests/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 26,  87 => 22,  82 => 21,  70 => 20,  64 => 19,  58 => 18,  52 => 17,  46 => 16,  41 => 15,  38 => 14,  33 => 13,  19 => 1,);
    }
}
