<?php

/* Tests/start.htm */
class __TwigTemplate_4f1dfe4a054ad39fe8fa82746f2d7410 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "    <h2>Тест: \"";
        if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
        echo $this->getAttribute($_test_, "title");
        echo "\"</h2><a href=\"/tests/stop\" style=\"float:right;margin-top: -25px;\"><span>Окончить тест</span></a>
    <div id=\"container\" style=\"margin-left: -150px;\">
        <div id=\"carousel\">
            ";
        // line 4
        if (isset($context["questions"])) { $_questions_ = $context["questions"]; } else { $_questions_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_questions_);
        foreach ($context['_seq'] as $context["_key"] => $context["question"]) {
            // line 5
            echo "            <div  class=\"slide \">
                <h3>";
            // line 6
            if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
            echo $this->getAttribute($_question_, "text");
            echo "</h3><br>
                ";
            // line 7
            if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
            if (($this->getAttribute($_question_, "type") == 0)) {
                // line 8
                echo "                    <form id=\"form";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\" method=\"post\" >
                        <input type=\"hidden\" name=\"priority\" value=\"";
                // line 9
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "priority");
                echo "\">
                        <input type=\"hidden\" name=\"themes_id\" value=\"";
                // line 10
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "themes_id");
                echo "\">
                    Введите ответ:
                    <input type=\"text\" name=\"answer\" id=\"answer";
                // line 12
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\" >
                        <input type=\"button\" id=\"";
                // line 13
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\" value=\"ответить\" onclick=\"AjaxFormRequest('form";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "', '";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "')\" >
                    </form>
                ";
            }
            // line 16
            echo "
                ";
            // line 17
            if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
            if (($this->getAttribute($_question_, "type") == 1)) {
                // line 18
                echo "                    <form id=\"form";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\" method=\"post\" class=\"test\" >
                        <input type=\"hidden\" name=\"question_id\" value=\"";
                // line 19
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\">
                        <input type=\"hidden\" name=\"priority\" value=\"";
                // line 20
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "priority");
                echo "\">
                        <input type=\"hidden\" name=\"themes_id\" value=\"";
                // line 21
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "themes_id");
                echo "\">
                        Выбирите правильный ответ:<br>
                        <div id=\"answer";
                // line 23
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\"><strong>";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "answer_correct");
                echo "</strong><input type=\"radio\" name=\"answer\" class=\"answer\"   value=\"";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "answer_correct");
                echo "\" ></div><br>
                        ";
                // line 24
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($_question_, "answers"));
                foreach ($context['_seq'] as $context["_key"] => $context["answer"]) {
                    // line 25
                    echo "                        <script type=\"text/javascript\">
                            if(getRandomInt(0,1) == 0){
                                \$('#answer";
                    // line 27
                    if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                    echo $this->getAttribute($_question_, "id");
                    echo "').after('<br><div><strong>";
                    if (isset($context["answer"])) { $_answer_ = $context["answer"]; } else { $_answer_ = null; }
                    echo $_answer_;
                    echo "</strong><input type=\"radio\" name=\"answer\" class=\"answer\"  value=\"";
                    if (isset($context["answer"])) { $_answer_ = $context["answer"]; } else { $_answer_ = null; }
                    echo $_answer_;
                    echo "\" ></div><br>');
                            }
                            else{
                                \$('#answer";
                    // line 30
                    if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                    echo $this->getAttribute($_question_, "id");
                    echo "').before('<br><div><strong>";
                    if (isset($context["answer"])) { $_answer_ = $context["answer"]; } else { $_answer_ = null; }
                    echo $_answer_;
                    echo "</strong><input type=\"radio\" name=\"answer\" class=\"answer\"  value=\"";
                    if (isset($context["answer"])) { $_answer_ = $context["answer"]; } else { $_answer_ = null; }
                    echo $_answer_;
                    echo "\" ></div><br>');
                            }
                        </script>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['answer'], $context['_parent'], $context['loop']);
                $context = array_merge($_parent, array_intersect_key($context, $_parent));
                // line 34
                echo "                        <input type=\"button\" id=\"";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "\" value=\"ответить\" onclick=\"AjaxFormRequest('form";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "', '";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo $this->getAttribute($_question_, "id");
                echo "')\" >
                    </form>
                ";
            }
            // line 37
            echo "            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['question'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 39
        echo "
        </div>
        <a href=\"#\"  style=\"float:right\"    id=\"ui-carousel-next\"><span>след.</span></a>
        <a href=\"#\" id=\"ui-carousel-prev\"><span>прев.</span></a>

        <div id=\"pages\"></div>
    </div>

<script type=\"text/javascript\">



    function AjaxFormRequest(form_id,url) {
        jQuery.ajax({
            url:     \"/tests/save_answer/\"+url,
            type:     \"POST\",
            dataType: \"html\",
            data: jQuery(\"#\"+form_id).serialize(),
            success: function(response) {
                \$('#alert').html( response );

            },
            error: function(response) {
                \$('#alert').html( response );
            }
        });
    }
</script>

";
    }

    public function getTemplateName()
    {
        return "Tests/start.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 39,  170 => 37,  156 => 34,  139 => 30,  126 => 27,  122 => 25,  117 => 24,  106 => 23,  100 => 21,  95 => 20,  90 => 19,  84 => 18,  81 => 17,  78 => 16,  65 => 13,  60 => 12,  54 => 10,  49 => 9,  43 => 8,  40 => 7,  35 => 6,  32 => 5,  27 => 4,  19 => 1,);
    }
}
