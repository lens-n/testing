<?php

/* Questions/add.htm */
class __TwigTemplate_042e78a9e5c2e593815f2a23944363b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Добавление вопроса:</h2>
";
        // line 2
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "create", array(0 => "Question", 1 => array("class" => "form")), "method");
        echo "

    ";
        // line 4
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "id"), "method");
        echo "

    <div class=\"row\">
        <label>Предмет:</label>
        <div class=\"row\">
            <select name=\"data[Question][subjects_id]\" id=\"subject_id\" >
                ";
        // line 10
        if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_subjects_);
        foreach ($context['_seq'] as $context["_key"] => $context["subject"]) {
            // line 11
            echo "                    <option ";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_subject_, "Subject"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "subjects_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "id");
            echo "\">";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "title");
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subject'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 13
        echo "            </select>
        </div>
    </div>
    <div class=\"row\">
        <label>Темы:</label>
        <div class=\"row\" >
            <select name=\"data[Question][themes_id]\" id=\"themes\" >

            </select>

        </div>
    </div>
<div class=\"row\">
    <label>Приоретет ответа:</label>
    <div class=\"row\">
        <select name=\"data[Question][priority]\" id=\"priority\" >


            <option ";
        // line 31
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "priority", array(), "array") == 0)) {
            echo "selected=\"selected\" ";
        }
        echo " value=\"0\">100%</option>
            <option ";
        // line 32
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "priority", array(), "array") == 1)) {
            echo "selected=\"selected\" ";
        }
        echo " value=\"1\">50%</option>


        </select>
    </div>
</div>

        <div class=\"section\">
            <label>Текст воароса:</label>
            <p class=\"error\"></p>
            ";
        // line 42
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "text", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>
<div class=\"row\">
    <label>Тип ответа:</label>
    <div class=\"row\">
        <select name=\"data[Question][type]\" id=\"type\" >


                <option ";
        // line 50
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "type", array(), "array") == 0)) {
            echo "selected=\"selected\" ";
        }
        echo " value=\"0\">Вписать</option>
            <option ";
        // line 51
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "type", array(), "array") == 1)) {
            echo "selected=\"selected\" ";
        }
        echo " value=\"1\">Выбрать один вариант</option>
              ";
        // line 53
        echo "
        </select>
    </div>
</div>

<div class=\"row\">
    <label id=\"add_answer2\">Ответ:</label>
    <div class=\"row\" id=\"answers\">
        ";
        // line 61
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "answer_correct", 1 => array("div" => false, "label" => false, "type" => "text")), "method");
        echo "
    </div>
</div>
    <div class=\"section last\">
        <div>
            ";
        // line 66
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "submit", array(0 => "Сохранить", 1 => array("class" => "btn btn-primary")), "method");
        echo "
        </div>
    </div>

    ";
        // line 70
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "end", array(), "method");
        echo "

<script type=\"text/javascript\">
    \$(function() {
//edit
";
        // line 75
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if ($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array")) {
            // line 76
            echo "
        subject_id = \$('#subject_id').val() ;
        \$.post( \"/questions/getThemes/\" + subject_id + '/' + ";
            // line 78
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "themes_id", array(), "array");
            echo ", function(data ) {
            \$('#themes').html( data );

        });


        qt = ";
            // line 84
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            echo twig_length_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "answers", array(), "array"));
            echo ";

        ";
            // line 86
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "type", array(), "array") == 1)) {
                // line 87
                echo "        str = '';
        ";
                // line 88
                if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "answers", array(), "array"));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["answer"]) {
                    // line 89
                    echo "            str += '<input name=\"data[Question][_serialize][]\" value=\"";
                    if (isset($context["answer"])) { $_answer_ = $context["answer"]; } else { $_answer_ = null; }
                    echo $_answer_;
                    echo "\" type=\"text\" id =\"qst";
                    if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
                    echo $this->getAttribute($_loop_, "index");
                    echo "\"><br>';
        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['answer'], $context['_parent'], $context['loop']);
                $context = array_merge($_parent, array_intersect_key($context, $_parent));
                // line 91
                echo "
        \$('#answers').html( '<label>Правильный ответ:</label><br><input name=\"data[Question][answer_correct]\" value=\"";
                // line 92
                if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
                echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Question", array(), "array"), "answer_correct", array(), "array");
                echo "\" type=\"text\" id=\"QuestionAnswerCorrect\"><br>Остальные:<button  id=\"add_answer\">+</button><br>' +
                str );
        ";
            }
            // line 95
            echo "
        ";
        } else {
            // line 97
            echo "        subject_id = \$('#subject_id').val() ;
        \$.post( \"/questions/getThemes/\" + subject_id, function(data ) {
            \$('#themes').html( data );

        });



        qt = 1;




";
        }
        // line 111
        echo "
        \$('#type').change(function() {

            switch (\$(\"#type\").val()) {
                case '0' :
                    \$('#answers').html( '<input name=\"data[Question][answer_correct]\" type=\"text\" id=\"QuestionAnswerCorrect\">' );
                    break;
                case '1' :
                    \$('#answers').html( '<label>Правильный ответ:</label><br><input name=\"data[Question][answer_correct]\" type=\"text\" id=\"QuestionAnswerCorrect\"><br>Остальные:<button  id=\"add_answer\" >+</button><br>' +
                            '<input name=\"data[Question][_serialize][]\" type=\"text\" id =\"qst1\">' );
                    break;
                case '2' :
                    alert('2');
                    break;

            }

        });






        \$('#answers').on('click', '#add_answer', function(){
            if(qt < 3){
            \$('#qst' + qt).after('<br><input name=\"data[Question][_serialize][]\" type=\"text\" id=\"qst' + (qt+1)  + '\">');
            qt++;
            }else
                alert('Максимум 4 варианта!');
            return false;
        });





        \$('#subject_id').change(function() {
            subject_id = \$('#subject_id').val() ;
            \$.post( \"/questions/getThemes/\" + subject_id, function(data ) {
                \$('#themes').html( data );

            });
        });





       // \$('#answers').html( '' );

    });





</script>













";
    }

    public function getTemplateName()
    {
        return "Questions/add.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  265 => 111,  249 => 97,  245 => 95,  238 => 92,  235 => 91,  214 => 89,  196 => 88,  193 => 87,  190 => 86,  184 => 84,  174 => 78,  170 => 76,  167 => 75,  158 => 70,  150 => 66,  141 => 61,  131 => 53,  124 => 51,  117 => 50,  105 => 42,  89 => 32,  82 => 31,  62 => 13,  43 => 11,  38 => 10,  28 => 4,  22 => 2,  19 => 1,);
    }
}
