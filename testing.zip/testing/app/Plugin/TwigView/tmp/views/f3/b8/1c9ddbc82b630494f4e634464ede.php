<?php

/* Faculties/add.htm */
class __TwigTemplate_f3b81c9ddbc82b630494f4e634464ede extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Добавление факультета:</h2>
";
        // line 2
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "create", array(0 => "Faculty", 1 => array("class" => "form")), "method");
        echo "

    ";
        // line 4
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "id"), "method");
        echo "

        <div class=\"section\">
            <label>Имя факультета:</label>
            <p class=\"error\"></p>
            ";
        // line 9
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "title", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>
    <div class=\"section last\">
        <div>
            ";
        // line 13
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "submit", array(0 => "Сохранить", 1 => array("class" => "btn btn-primary")), "method");
        echo "
        </div>
    </div>

    ";
        // line 17
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "end", array(), "method");
        echo "














";
    }

    public function getTemplateName()
    {
        return "Faculties/add.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 17,  45 => 13,  37 => 9,  28 => 4,  22 => 2,  19 => 1,);
    }
}
