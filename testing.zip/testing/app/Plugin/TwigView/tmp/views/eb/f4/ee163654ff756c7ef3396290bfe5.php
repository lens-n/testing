<?php

/* Teachers/index.htm */
class __TwigTemplate_ebf4ee163654ff756c7ef3396290bfe5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Преподаватели:</h2>

<table class=\"table table-striped\">
    ";
        // line 4
        if (isset($context["teachers"])) { $_teachers_ = $context["teachers"]; } else { $_teachers_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_teachers_);
        foreach ($context['_seq'] as $context["_key"] => $context["teacher"]) {
            // line 5
            echo "        <tr>
            <td>";
            // line 6
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "sname");
            echo "</td>
            <td>";
            // line 7
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "fname");
            echo "</td>
            <td> ";
            // line 8
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "pname");
            echo "</td>
            <td><a href=\"/teachers/edit/";
            // line 9
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "id");
            echo "\">изменить</a></td>
            <td><a href=\"/teachers/del/";
            // line 10
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "id");
            echo "\" style=\"color: red\">x</a></td>

        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['teacher'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 14
        echo "</table>

<a href=\"/teachers/add\">Добавить</a>















";
    }

    public function getTemplateName()
    {
        return "Teachers/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 14,  52 => 10,  47 => 9,  42 => 8,  37 => 7,  32 => 6,  29 => 5,  24 => 4,  19 => 1,);
    }
}
