<?php

/* Layouts/front-end.htm */
class __TwigTemplate_3974fe97c919470df56df0b93d0ac242 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
    <title>";
        // line 5
        if (isset($context["title_for_layout"])) { $_title_for_layout_ = $context["title_for_layout"]; } else { $_title_for_layout_ = null; }
        echo ((array_key_exists("title_for_layout", $context)) ? (_twig_default_filter($_title_for_layout_, "Testing")) : ("Testing"));
        echo "</title>
    <link href=\"/css/style.css\" rel=\"stylesheet\" type=\"text/css\" />
    <link href=\"/bootstrap/css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" />
    <script type=\"text/javascript\" src=\"/js/jquery-1.10.2.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bootstrap/js/bootstrap.js\"></script>
</head>

<body>
<div id=\"topPan\">


    <a href=\"/\"><img src=\"/images/logo_onmu.png\"  class=\"logo\"/></a>

    <h3 id=\"alert\" style=\"color: green;float: right;margin-top: 100px; margin-left: 50px\"></h3>
</div>
<div id=\"bodyPan\">
    <h2>";
        // line 21
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($this->getAttribute($__view_, "session"), "flash", array(), "method");
        echo "</h2>
    ";
        // line 22
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($__view_, "fetch", array(0 => "content"), "method");
        echo "

</div>
<div id=\"bodybottomPan\">
</div>
";
        // line 27
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($__view_, "element", array(0 => "footer-front"), "method");
        echo "

</body>
</html>








";
    }

    public function getTemplateName()
    {
        return "Layouts/front-end.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 27,  50 => 22,  45 => 21,  25 => 5,  19 => 1,);
    }
}
