<?php

/* Tests/getstudent.htm */
class __TwigTemplate_392cb0e3b7f0b4dc98f8b8f2ef1f8fc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Список студентов</h2>
<table class=\"table table-striped\"   >
    ";
        // line 3
        if (isset($context["students"])) { $_students_ = $context["students"]; } else { $_students_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_students_);
        foreach ($context['_seq'] as $context["_key"] => $context["student"]) {
            // line 4
            echo "        <tr>
            <td>";
            // line 5
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "id");
            echo "</td>

            <td> ";
            // line 7
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "sname");
            echo "</td>
            <td>";
            // line 8
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "fname");
            echo "</td>
            <td>";
            // line 9
            if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
            echo $this->getAttribute($this->getAttribute($_student_, "Student"), "pname");
            echo "</td>
            ";
            // line 10
            if (isset($context["tests"])) { $_tests_ = $context["tests"]; } else { $_tests_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($_tests_);
            foreach ($context['_seq'] as $context["_key"] => $context["test"]) {
                // line 11
                echo "            <td>
                <a href=\"/tests/start/";
                // line 12
                if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
                echo $this->getAttribute($this->getAttribute($_test_, "Test"), "id");
                echo "/";
                if (isset($context["student"])) { $_student_ = $context["student"]; } else { $_student_ = null; }
                echo $this->getAttribute($this->getAttribute($_student_, "Student"), "id");
                echo "\"> Начать тест \"";
                if (isset($context["test"])) { $_test_ = $context["test"]; } else { $_test_ = null; }
                echo $this->getAttribute($this->getAttribute($_test_, "Test"), "title");
                echo "\"</a>
            </td>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['test'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 15
            echo "
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['student'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 18
        echo "</table>





";
    }

    public function getTemplateName()
    {
        return "Tests/getstudent.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 18,  76 => 15,  60 => 12,  57 => 11,  52 => 10,  47 => 9,  42 => 8,  37 => 7,  31 => 5,  28 => 4,  23 => 3,  19 => 1,);
    }
}
