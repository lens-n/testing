<?php

/* Tests/add.htm */
class __TwigTemplate_7eae47075efcca549ef10ea170f219b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Добавление теста:</h2>
";
        // line 2
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "create", array(0 => "Test", 1 => array("class" => "form")), "method");
        echo "

    ";
        // line 4
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "id"), "method");
        echo "
    ";
        // line 5
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "date"), "method");
        echo "

        <div class=\"row\">
            <label>Название теста:</label>
            <p class=\"error\"></p>
            ";
        // line 10
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "title", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>

<div class=\"row\">
    <label>Предмет:</label>

        <select name=\"data[Test][subject_id]\" id=\"subject_id\" >
            ";
        // line 17
        if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_subjects_);
        foreach ($context['_seq'] as $context["_key"] => $context["subject"]) {
            // line 18
            echo "                <option ";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_subject_, "Subject"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "subject_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "id");
            echo "\">";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "title");
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subject'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 20
        echo "        </select>

</div>
<div class=\"row\">
    <label>Темы:</label>
    <div  id=\"themes\">

    </div>
</div>
<div class=\"row\">
    <label>Курс:</label>

        <select name=\"data[Test][cours_id]\" id=\"cours_id\" >
            ";
        // line 33
        if (isset($context["courses"])) { $_courses_ = $context["courses"]; } else { $_courses_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_courses_);
        foreach ($context['_seq'] as $context["_key"] => $context["cours"]) {
            // line 34
            echo "                <option ";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_cours_, "Cours"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "cours_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "id");
            echo "\">";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "title");
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cours'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 36
        echo "        </select>

</div>
<div class=\"row\">
    <label>Факультет:</label>

        <select name=\"data[Test][faculty_id]\" id=\"faculty_id\" >
            ";
        // line 43
        if (isset($context["faculties"])) { $_faculties_ = $context["faculties"]; } else { $_faculties_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_faculties_);
        foreach ($context['_seq'] as $context["_key"] => $context["faculty"]) {
            // line 44
            echo "                <option ";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "faculty_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id");
            echo "\">";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "title");
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['faculty'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 46
        echo "        </select>

</div>


<div class=\"row\">
    <label>Группа:</label>

        <select name=\"data[Test][group_id]\" id=\"groups\" >
            ";
        // line 55
        if (isset($context["groups"])) { $_groups_ = $context["groups"]; } else { $_groups_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_groups_);
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 56
            echo "                <option ";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_group_, "Group"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "group_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            echo $this->getAttribute($this->getAttribute($_group_, "Group"), "id");
            echo "\">";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            echo $this->getAttribute($this->getAttribute($_group_, "Group"), "title");
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 58
        echo "        </select>

</div>
<div class=\"row\">
    <label>Преподователь:</label>

        <select name=\"data[Test][teacher_id]\" id=\"teacher_id\" >
            ";
        // line 65
        if (isset($context["teachers"])) { $_teachers_ = $context["teachers"]; } else { $_teachers_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_teachers_);
        foreach ($context['_seq'] as $context["_key"] => $context["teacher"]) {
            // line 66
            echo "                <option ";
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "teacher_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "id");
            echo "\">";
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "sname");
            echo " ";
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "fname");
            echo " ";
            if (isset($context["teacher"])) { $_teacher_ = $context["teacher"]; } else { $_teacher_ = null; }
            echo $this->getAttribute($this->getAttribute($_teacher_, "Teacher"), "pname");
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['teacher'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 68
        echo "        </select>

</div>
<div class=\"row\">
    <label>Начало диапазона IP:</label>
    ";
        // line 73
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "Test.config.min_ip", 1 => array("div" => false, "label" => false)), "method");
        echo "
</div>
<div class=\"row\">
    <label>Конец диапазона IP:</label>
    ";
        // line 77
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "Test.config.max_ip", 1 => array("div" => false, "label" => false)), "method");
        echo "
</div>
<div class=\"row\">
    <label>Мин. кол. вопросов по теме:</label>

        <select name=\"data[Test][config][min]\"  >
            ";
        // line 83
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(2, 4));
        foreach ($context['_seq'] as $context["_key"] => $context["min"]) {
            // line 84
            echo "            <option ";
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (isset($context["min"])) { $_min_ = $context["min"]; } else { $_min_ = null; }
            if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "config", array(), "array"), "min", array(), "array") == $_min_)) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["min"])) { $_min_ = $context["min"]; } else { $_min_ = null; }
            echo $_min_;
            echo "\">";
            if (isset($context["min"])) { $_min_ = $context["min"]; } else { $_min_ = null; }
            echo $_min_;
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['min'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 86
        echo "

        </select>

</div>
<div class=\"row\">
    <label>Макс. кол. вопросов по теме:</label>

        <select name=\"data[Test][config][max]\"  >
            ";
        // line 95
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(4, 8));
        foreach ($context['_seq'] as $context["_key"] => $context["max"]) {
            // line 96
            echo "                <option ";
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (isset($context["max"])) { $_max_ = $context["max"]; } else { $_max_ = null; }
            if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "config", array(), "array"), "max", array(), "array") == $_max_)) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["max"])) { $_max_ = $context["max"]; } else { $_max_ = null; }
            echo $_max_;
            echo "\">";
            if (isset($context["max"])) { $_max_ = $context["max"]; } else { $_max_ = null; }
            echo $_max_;
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['max'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 98
        echo "        </select>

</div>
<div class=\"row\">
    <label>Алгоритм подсчета:</label>

    <select name=\"data[Test][config][algo]\"  >

            <option ";
        // line 106
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "config", array(), "array"), "algo", array(), "array") == "middle")) {
            echo "selected=\"selected\" ";
        }
        echo " value=\"middle\">Среднее</option>
            <option ";
        // line 107
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if (($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "config", array(), "array"), "algo", array(), "array") == "all_done")) {
            echo "selected=\"selected\" ";
        }
        echo " value=\"all_done\">Благориятный</option>

    </select>

</div>





";
        // line 128
        echo "
    <div class=\"row\">
        <div>
            ";
        // line 131
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "submit", array(0 => "Сохранить", 1 => array("class" => "btn btn-primary")), "method");
        echo "
        </div>
    </div>

    ";
        // line 135
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "end", array(), "method");
        echo "
<script type=\"text/javascript\">
    \$(function() {


///Edit
";
        // line 141
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        if ($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array")) {
            // line 142
            echo "        id = \$('#cours_id').val() + '/' + \$('#faculty_id').val();
        \$.post( \"/students/getGroup/\" + id + '/' +";
            // line 143
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "group_id", array(), "array");
            echo " , function(data ) {
            \$('#groups').html( data );

        });

            subject_id = ";
            // line 148
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "subject_id", array(), "array");
            echo " ;
            checked = \$.parseJSON( '";
            // line 149
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Test", array(), "array"), "themes", array(), "array");
            echo "' );

            \$.ajax({
                type: \"POST\",
                data: {subject_id:subject_id, checked :checked},
                url: \"/tests/getThemes/\",
                success: function(data){
                    \$('#themes').html( data );
                }
            });
";
        } else {
            // line 160
            echo "        id = \$('#cours_id').val() + '/' + \$('#faculty_id').val();
        \$.post( \"/students/getGroup/\" + id, function(data ) {
            \$('#groups').html( data );

        });
        subject_id = \$('#subject_id').val() ;
        \$.post( \"/tests/getThemes/\" + subject_id, function(data ) {
            \$('#themes').html( data );

        });
";
        }
        // line 171
        echo "


        \$('#subject_id').change(function() {
            subject_id = \$('#subject_id').val() ;
            \$.post( \"/tests/getThemes/\" + subject_id, function(data ) {
                \$('#themes').html( data );

            });
        });

        \$('#cours_id, #faculty_id').change(function() {

            id = \$('#cours_id').val() + '/' + \$('#faculty_id').val();
            \$.post( \"/students/getGroup/\" + id, function(data ) {
                \$('#groups').html( data );
            });
        });

        \$('#TestEditForm , #TestAddForm').submit(function() {

           if(\$( \"input:checked\" ).length == 0){
               alert('Выбирете тему!');
               return false
           }
        });

    });



</script>














";
    }

    public function getTemplateName()
    {
        return "Tests/add.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  409 => 171,  396 => 160,  381 => 149,  376 => 148,  367 => 143,  364 => 142,  361 => 141,  351 => 135,  343 => 131,  338 => 128,  322 => 107,  315 => 106,  305 => 98,  286 => 96,  282 => 95,  271 => 86,  252 => 84,  248 => 83,  238 => 77,  230 => 73,  223 => 68,  198 => 66,  193 => 65,  184 => 58,  165 => 56,  160 => 55,  149 => 46,  130 => 44,  125 => 43,  116 => 36,  97 => 34,  92 => 33,  77 => 20,  58 => 18,  53 => 17,  42 => 10,  33 => 5,  28 => 4,  22 => 2,  19 => 1,);
    }
}
