<?php

/* Layouts/test.htm */
class __TwigTemplate_7f083207a9cdd5ec207b3e8ff0537a42 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
    <title>";
        // line 5
        if (isset($context["title_for_layout"])) { $_title_for_layout_ = $context["title_for_layout"]; } else { $_title_for_layout_ = null; }
        echo ((array_key_exists("title_for_layout", $context)) ? (_twig_default_filter($_title_for_layout_, "Testing")) : ("Testing"));
        echo "</title>
    <link href=\"/css/style.css\" rel=\"stylesheet\" type=\"text/css\" />
    <link href='http://fonts.googleapis.com/css?family=Anton|Ubuntu' rel='stylesheet' type='text/css'>
    <link type=\"text/css\" rel=\"stylesheet\" href=\"/css/reset.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"/css/style.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"/css/rcarousel.css\" />
    <link href=\"/bootstrap/css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" />
    <script type=\"text/javascript\" src=\"/js/jquery-1.10.2.min.js\"></script>
    <script type=\"text/javascript\" src=\"/js/jquery.ui.core.js\"></script>
    <script type=\"text/javascript\" src=\"/js/jquery.ui.widget.js\"></script>
    <script type=\"text/javascript\" src=\"/js/jquery.ui.rcarousel.js\"></script>
    <script type=\"text/javascript\">
        jQuery(function(\$) {
            function generatePages() {
                var _total, i, _link;

                _total = \$( \"#carousel\" ).rcarousel( \"getTotalPages\" );


                for ( i = 0; i < _total; i++ ) {
                    _link = \$( \"<a href='#'></a>\" );

                    \$(_link)
                            .bind(\"click\", {page: i},
                            function( event ) {
                                \$( \"#carousel\" ).rcarousel( \"goToPage\", event.data.page );
                                event.preventDefault();
                            }
                    )
                            .addClass( \"bullet off\" )
                            .appendTo( \"#pages\" );
                }

                // mark first page as active
                \$( \"a:eq(0)\", \"#pages\" )
                        .removeClass( \"off\" )
                        .addClass( \"on\" )
                        .css( \"background-image\", \"url(/images/images/page-on.png)\" );

            }

            function pageLoaded( event, data ) {
                \$( \"a.on\", \"#pages\" )
                        .removeClass( \"on\" )
                        .css( \"background-image\", \"url(/images/images/page-off.png)\" );

                \$( \"a\", \"#pages\" )
                        .eq( data.page )
                        .addClass( \"on\" )
                        .css( \"background-image\", \"url(/images/images/page-on.png)\" );
            }

            \$(\"#carousel\").rcarousel(
                    {
                        visible: 1,
                        step: 1,
                        speed: 700,
                        auto: {
                            enabled: false
                        },
                        width: 780,
                        height: 400,
                        start: generatePages,
                        pageLoaded: pageLoaded
                    }
            );

            \$( \"#ui-carousel-next\" )
                    .add( \"#ui-carousel-prev\" )
                    .add( \".bullet\" )
                    .hover(
                    function() {
                        \$( this ).css( \"opacity\", 0.7 );
                    },
                    function() {
                        \$( this ).css( \"opacity\", 1.0 );
                    }
            );
        });


        function getRandomInt(min, max)
        {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }


    </script>
</head>
<style type=\"text/css\">
    #container {
        width: 940px;
        position: relative;
        margin: 0 auto;
    }

    #carousel {
        width: 780px;
        margin: 0 auto;
        height: auto;
    }

/*    #ui-carousel-next, #ui-carousel-prev {
        width: 60px;
        height: 240px;
        background: url(/images/images/arrow-left.png) #fff center center no-repeat;
        display: block;
        position: absolute;
        top: 0;
        z-index: 100;
    }

    #ui-carousel-next {
        right: 0;
        background-image: url(/images/images/arrow-right.png);
    }*/

    #ui-carousel-prev {
        left: 0;
    }

    #ui-carousel-next > span, #ui-carousel-prev > span {
        display:block;
    }

    .slide {
        margin: 0;
        position: relative;
        height: auto;
        text-align: center;
        background: #D7E2DF;
        border-radius: 30px;
    }

    .slide form{
        text-align: left;
        margin-left: 50px;
    }

    .slide  h2 {
        font: 72px/1 Anton, sans-serif;
        color: #ff5c43;
        margin: 0;
        padding: 0;
    }

    .slide  p {
        font: 32px/1 Ubuntu, sans-serif;
        color: #4d4d4d;
        margin: 0;
        padding: 0;
    }

    #slide01 > img {
        position: absolute;
        bottom: 35px;
        left: 30px;
    }

    #slide01 > .text {
        position: absolute;
        left: 290px;
        bottom: 35px;
    }


    #pages {
        width: 150px;
        margin: 0 auto;
    }

    .bullet {
        background: url(/images/images/page-off.png) center center no-repeat;
        display: block;
        width: 18px;
        height: 18px;
        margin: 0;
        margin-right: 5px;
        float: left;
    }


</style>

<body>
<div id=\"topPan\">


    <a href=\"/\"><img src=\"/images/logo_onmu.png\"  class=\"logo\"/></a>
    <h2 id=\"alert\" style=\"color: green;
float: right;
margin-top: 100px;\"></h2>
</div>


<div id=\"bodyPan\">
    <h2>";
        // line 201
        if (isset($context["session"])) { $_session_ = $context["session"]; } else { $_session_ = null; }
        echo $this->getAttribute($_session_, "flash", array(), "method");
        echo "</h2>
    ";
        // line 202
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($__view_, "fetch", array(0 => "content"), "method");
        echo "

</div>
<div id=\"bodybottomPan\">

</div>
";
        // line 208
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($__view_, "element", array(0 => "footer-front"), "method");
        echo "

</body>
</html>








";
    }

    public function getTemplateName()
    {
        return "Layouts/test.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  240 => 208,  230 => 202,  225 => 201,  25 => 5,  19 => 1,);
    }
}
