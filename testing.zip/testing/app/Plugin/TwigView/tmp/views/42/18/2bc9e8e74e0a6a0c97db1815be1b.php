<?php

/* Subjects/index.htm */
class __TwigTemplate_42182bc9e8e74e0a6a0c97db1815be1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Предметы:</h2>
<table class=\"table table-striped\" style=\"width: 40%\">
<tr>
    <th>Предмет</th>
    <th></th>
    <th></th>
</tr>
    ";
        // line 8
        if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_subjects_);
        foreach ($context['_seq'] as $context["_key"] => $context["subject"]) {
            // line 9
            echo "<tr>
    <td> ";
            // line 10
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "title");
            echo " </td>
    <td><a href=\"/subjects/edit/";
            // line 11
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "id");
            echo "\">изменить</a></td>
    <td> <a href=\"/subjects/del/";
            // line 12
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "id");
            echo "\" style=\"color: #f00\">x</a></td>
</tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subject'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 15
        echo "
</table>



<a href=\"/subjects/add\">Добавить</a>















";
    }

    public function getTemplateName()
    {
        return "Subjects/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 15,  46 => 12,  41 => 11,  36 => 10,  33 => 9,  28 => 8,  19 => 1,);
    }
}
