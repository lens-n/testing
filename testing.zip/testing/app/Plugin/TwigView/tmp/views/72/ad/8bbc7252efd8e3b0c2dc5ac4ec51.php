<?php

/* Themes/add.htm */
class __TwigTemplate_72ad8bbc7252efd8e3b0c2dc5ac4ec51 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Добавление темы:</h2>
";
        // line 2
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "create", array(0 => "Theme", 1 => array("class" => "form")), "method");
        echo "

    ";
        // line 4
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "id"), "method");
        echo "

        <div class=\"row\">
            <label>Имя группы:</label>

            ";
        // line 9
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "title", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>

    <div class=\"row\">
        <label>Предмет:</label>

            <select name=\"data[Theme][subjects_id]\" id=\"subject_id\" >
                ";
        // line 16
        if (isset($context["subjects"])) { $_subjects_ = $context["subjects"]; } else { $_subjects_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_subjects_);
        foreach ($context['_seq'] as $context["_key"] => $context["subject"]) {
            // line 17
            echo "                    <option ";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_subject_, "Subject"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Theme", array(), "array"), "subjects_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "id");
            echo "\">";
            if (isset($context["subject"])) { $_subject_ = $context["subject"]; } else { $_subject_ = null; }
            echo $this->getAttribute($this->getAttribute($_subject_, "Subject"), "title");
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subject'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 19
        echo "            </select>

    </div>


    <div class=\"row\">
        <div>
            ";
        // line 26
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "submit", array(0 => "Сохранить", 1 => array("class" => "btn btn-primary")), "method");
        echo "
        </div>
    </div>

    ";
        // line 30
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "end", array(), "method");
        echo "














";
    }

    public function getTemplateName()
    {
        return "Themes/add.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 30,  81 => 26,  72 => 19,  53 => 17,  48 => 16,  37 => 9,  28 => 4,  22 => 2,  19 => 1,);
    }
}
