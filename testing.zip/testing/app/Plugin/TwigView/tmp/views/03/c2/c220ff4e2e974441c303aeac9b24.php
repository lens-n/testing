<?php

/* Faculties/index.htm */
class __TwigTemplate_03c2c220ff4e2e974441c303aeac9b24 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Факультеты:</h2>

<table class=\"table table-striped\" style=\"width: 40%\">
    <tr>
        <th>Название</th>
        <th></th>
        <th></th>
    </tr>
    ";
        // line 9
        if (isset($context["faculties"])) { $_faculties_ = $context["faculties"]; } else { $_faculties_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_faculties_);
        foreach ($context['_seq'] as $context["_key"] => $context["faculty"]) {
            // line 10
            echo "        <tr>
            <td> ";
            // line 11
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "title");
            echo " </td>
            <td><a href=\"/faculties/edit/";
            // line 12
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id");
            echo "\">изменить</a></td>
            <td> <a href=\"/faculties/delete/";
            // line 13
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id");
            echo "\">x</a></td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['faculty'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 16
        echo "
</table>

<a href=\"/faculties/add\">Добавить</a>















";
    }

    public function getTemplateName()
    {
        return "Faculties/index.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 16,  47 => 13,  42 => 12,  37 => 11,  34 => 10,  29 => 9,  19 => 1,);
    }
}
