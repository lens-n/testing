<?php

/* Layouts/default.htm */
class __TwigTemplate_6dc80f651fd2e175376c0ef033d0addf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
    <title>";
        // line 5
        if (isset($context["title_for_layout"])) { $_title_for_layout_ = $context["title_for_layout"]; } else { $_title_for_layout_ = null; }
        echo ((array_key_exists("title_for_layout", $context)) ? (_twig_default_filter($_title_for_layout_, "Testing")) : ("Testing"));
        echo "</title>
    <link href=\"/css/style.css\" rel=\"stylesheet\" type=\"text/css\" />
    <link href=\"/bootstrap/css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" />
    <script type=\"text/javascript\" src=\"/js/jquery-1.10.2.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bootstrap/js/bootstrap.js\"></script>
</head>

<body>

<div id=\"topPan\">


    <a href=\"/\"><img src=\"/images/logo_onmu.png\"  class=\"logo\"/></a>
    <a href=\"/admin/logout\" class=\"btn btn-inverse\" style=\"float:right\">Logout</a>

    <h3 id=\"alert\" style=\"color: green;float: right;margin-top: 100px; margin-left: 50px\"></h3>




</div>
<!--Выпадающее меню-->
<ul class=\"nav nav-pills\" style=\"float: right;margin-right: 100px;margin-top: -37px;\">

    ";
        // line 30
        echo "        ";
        // line 31
        echo "        ";
        // line 32
        echo "            ";
        // line 33
        echo "            ";
        // line 34
        echo "            ";
        // line 35
        echo "            ";
        // line 36
        echo "        ";
        // line 37
        echo "        ";
        // line 38
        echo "    ";
        // line 39
        echo "


  ";
        // line 43
        echo "    <li class=\"dropdown\"><a href=\"/courses/\">Курсы</a> </li>
    <li class=\"dropdown\"><a href=\"/faculties/\">Факультеты</a> </li>
    <li class=\"dropdown\"><a href=\"/students/\">Студенты</a> </li>
    <li class=\"dropdown\"><a href=\"/teachers\">Преподователи</a> </li>
    <li class=\"dropdown\"><a href=\"/groups/\">Группы</a> </li>
    <li class=\"dropdown\"><a href=\"/subjects\">Предметы</a></li>
    <li class=\"dropdown\"><a href=\"/themes\">Темы</a></li>
    <li class=\"dropdown\"><a href=\"/tests\">Тесты</a></li>
    <li class=\"dropdown\"><a href=\"/questions\">Вопросы</a></li>
    <li class=\"dropdown\"><a href=\"/reports\">Отчеты</a></li>
</ul>
<!--.Выпадающее меню-->





<div id=\"bodyPan\">

    <h2>";
        // line 62
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($this->getAttribute($__view_, "session"), "flash", array(), "method");
        echo "</h2>
    ";
        // line 63
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($__view_, "fetch", array(0 => "content"), "method");
        echo "
</div>
<div id=\"bodybottomPan\">
</div>
";
        // line 67
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($__view_, "element", array(0 => "footer"), "method");
        echo "

</body>
</html>








";
    }

    public function getTemplateName()
    {
        return "Layouts/default.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 67,  102 => 63,  97 => 62,  76 => 43,  71 => 39,  69 => 38,  67 => 37,  65 => 36,  63 => 35,  61 => 34,  59 => 33,  57 => 32,  55 => 31,  53 => 30,  25 => 5,  19 => 1,);
    }
}
