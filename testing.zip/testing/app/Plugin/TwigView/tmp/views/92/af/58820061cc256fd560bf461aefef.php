<?php

/* Reports/view.htm */
class __TwigTemplate_92af58820061cc256fd560bf461aefef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Результаты:</h2>
";
        // line 2
        if (isset($context["themes_marks"])) { $_themes_marks_ = $context["themes_marks"]; } else { $_themes_marks_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_themes_marks_);
        foreach ($context['_seq'] as $context["_key"] => $context["theme"]) {
            // line 3
            echo "    Ваша  оценка по теме <strong>\"";
            if (isset($context["themes"])) { $_themes_ = $context["themes"]; } else { $_themes_ = null; }
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($this->getAttribute($_themes_, $this->getAttribute($_theme_, "id"), array(), "array"), "title", array(), "array");
            echo "\" : </strong> <strong>";
            if (isset($context["theme"])) { $_theme_ = $context["theme"]; } else { $_theme_ = null; }
            echo $this->getAttribute($_theme_, "mark");
            echo " балов </strong><br><br>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['theme'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 5
        echo "

Ваша оценка за весь тест: <strong>";
        // line 7
        if (isset($context["mark"])) { $_mark_ = $context["mark"]; } else { $_mark_ = null; }
        echo $_mark_;
        echo " балов</strong><br><br>

<strong>Отчет ответов:</strong><br><br>

";
        // line 11
        if (isset($context["reports"])) { $_reports_ = $context["reports"]; } else { $_reports_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_reports_);
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["report"]) {
            // line 12
            echo "<strong>";
            if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
            echo $this->getAttribute($_loop_, "index");
            echo ".</strong> ";
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_report_, "Question"), "text");
            echo "<br><br>
<strong> Ответ:<div class=\" ";
            // line 13
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            if (($this->getAttribute($this->getAttribute($_report_, "ReportQuestion"), "correct") == 1)) {
                echo " text-success";
            } else {
                echo "text-error";
            }
            echo " \"></strong><br>";
            if (isset($context["report"])) { $_report_ = $context["report"]; } else { $_report_ = null; }
            echo $this->getAttribute($this->getAttribute($_report_, "ReportQuestion"), "answer");
            echo "</div><br>
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['report'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 15
        echo "













";
    }

    public function getTemplateName()
    {
        return "Reports/view.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 15,  80 => 13,  71 => 12,  53 => 11,  45 => 7,  41 => 5,  27 => 3,  22 => 2,  19 => 1,);
    }
}
