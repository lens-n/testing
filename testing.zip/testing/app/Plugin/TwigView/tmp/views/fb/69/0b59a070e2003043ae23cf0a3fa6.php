<?php

/* Students/add.htm */
class __TwigTemplate_fb690b59a070e2003043ae23cf0a3fa6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Добавление студента:</h2>
";
        // line 2
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "create", array(0 => "Student", 1 => array("class" => "form")), "method");
        echo "

    ";
        // line 4
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "Student.id"), "method");
        echo "


        <div class=\"row\">
            <label>Фамилия:</label>
 
            ";
        // line 10
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "Student.sname", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>
        <div class=\"row\">
            <label>Имя:</label>
            ";
        // line 14
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "Student.fname", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>
        <div class=\"row\">
            <label>Отчество:</label>
          
            ";
        // line 19
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "Student.pname", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>
            <div class=\"row\">
                <label>Курс:</label>

                    <select name=\"data[Student][cours_id]\" id=\"cours_id\" >
                        ";
        // line 25
        if (isset($context["courses"])) { $_courses_ = $context["courses"]; } else { $_courses_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_courses_);
        foreach ($context['_seq'] as $context["_key"] => $context["cours"]) {
            // line 26
            echo "                            <option ";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_cours_, "Cours"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Student", array(), "array"), "cours_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "id");
            echo "\">";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "title");
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cours'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 28
        echo "                    </select>

            </div>
            <div class=\"row\">
                <label>Факультет:</label>

                    <select name=\"data[Student][faculty_id]\" id=\"faculty_id\" >
                        ";
        // line 35
        if (isset($context["faculties"])) { $_faculties_ = $context["faculties"]; } else { $_faculties_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_faculties_);
        foreach ($context['_seq'] as $context["_key"] => $context["faculty"]) {
            // line 36
            echo "                            <option ";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Student", array(), "array"), "faculty_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id");
            echo "\">";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "title");
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['faculty'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 38
        echo "                    </select>

            </div>
        <div class=\"row\">
            <label>Группа:</label>

                <select name=\"data[Student][group_id]\" id=\"groups\" >
                    ";
        // line 45
        if (isset($context["groups"])) { $_groups_ = $context["groups"]; } else { $_groups_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_groups_);
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 46
            echo "                        <option ";
            if (isset($context["grop"])) { $_grop_ = $context["grop"]; } else { $_grop_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_grop_, "Group"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Student", array(), "array"), "group_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            echo $this->getAttribute($this->getAttribute($_group_, "Group"), "id");
            echo "\">";
            if (isset($context["group"])) { $_group_ = $context["group"]; } else { $_group_ = null; }
            echo $this->getAttribute($this->getAttribute($_group_, "Group"), "title");
            echo "</option>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 48
        echo "                </select>

        </div>

    <div class=\"section last\">
        <div>
            ";
        // line 54
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "submit", array(0 => "Сохранить", 1 => array("class" => "btn btn-primary")), "method");
        echo "
        </div>
    </div>

    ";
        // line 58
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "end", array(), "method");
        echo "

<script type=\"text/javascript\">
    \$(function() {

    id = \$('#cours_id').val() + '/' + \$('#faculty_id').val();
        \$.post( \"/students/getGroup/\" + id + '/' + '";
        // line 64
        if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
        echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Student", array(), "array"), "group_id", array(), "array");
        echo "', function(data ) {
            \$('#groups').html( data );

        });


        \$('#cours_id, #faculty_id').change(function() {

            id = \$('#cours_id').val() + '/' + \$('#faculty_id').val();
            \$.post( \"/students/getGroup/\" + id , function(data ) {
                \$('#groups').html( data );
            });
        });

    });

</script>














";
    }

    public function getTemplateName()
    {
        return "Students/add.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 64,  171 => 58,  163 => 54,  155 => 48,  136 => 46,  131 => 45,  122 => 38,  103 => 36,  98 => 35,  89 => 28,  70 => 26,  65 => 25,  55 => 19,  46 => 14,  38 => 10,  28 => 4,  22 => 2,  19 => 1,);
    }
}
