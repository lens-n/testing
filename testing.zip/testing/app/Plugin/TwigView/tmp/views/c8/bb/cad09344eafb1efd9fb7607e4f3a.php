<?php

/* Groups/add.htm */
class __TwigTemplate_c8bbcad09344eafb1efd9fb7607e4f3a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2>Добавление группы:</h2>
";
        // line 2
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "create", array(0 => "Group", 1 => array("class" => "form")), "method");
        echo "

    ";
        // line 4
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "hidden", array(0 => "id"), "method");
        echo "

        <div class=\"row\">
            <label>Имя группы:</label>
          
            ";
        // line 9
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "input", array(0 => "title", 1 => array("div" => false, "label" => false)), "method");
        echo "
        </div>

    <div class=\"row\">
        <label>Факультет:</label>

            <select name=\"data[Group][faculties_id]\" id=\"group_id\" >
                ";
        // line 16
        if (isset($context["faculties"])) { $_faculties_ = $context["faculties"]; } else { $_faculties_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_faculties_);
        foreach ($context['_seq'] as $context["_key"] => $context["faculty"]) {
            // line 17
            echo "                    <option ";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Group", array(), "array"), "faculties_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "id");
            echo "\">";
            if (isset($context["faculty"])) { $_faculty_ = $context["faculty"]; } else { $_faculty_ = null; }
            echo $this->getAttribute($this->getAttribute($_faculty_, "Faculty"), "title");
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['faculty'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 19
        echo "            </select>

    </div>

    <div class=\"row\">
        <label>Курс:</label>

            <select name=\"data[Group][cours_id]\" id=\"shop_brands\" >
                ";
        // line 27
        if (isset($context["courses"])) { $_courses_ = $context["courses"]; } else { $_courses_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_courses_);
        foreach ($context['_seq'] as $context["_key"] => $context["cours"]) {
            // line 28
            echo "                    <option ";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            if (isset($context["_view"])) { $__view_ = $context["_view"]; } else { $__view_ = null; }
            if (($this->getAttribute($this->getAttribute($_cours_, "Cours"), "id") == $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($__view_, "request"), "data"), "Group", array(), "array"), "cours_id", array(), "array"))) {
                echo "selected=\"selected\" ";
            }
            echo " value=\"";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "id");
            echo "\">";
            if (isset($context["cours"])) { $_cours_ = $context["cours"]; } else { $_cours_ = null; }
            echo $this->getAttribute($this->getAttribute($_cours_, "Cours"), "title");
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cours'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 30
        echo "            </select>

    </div>
    <div class=\"section last\">
        <div>
            ";
        // line 35
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "submit", array(0 => "Сохранить", 1 => array("class" => "btn btn-primary")), "method");
        echo "
        </div>
    </div>

    ";
        // line 39
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->getAttribute($_form_, "end", array(), "method");
        echo "














";
    }

    public function getTemplateName()
    {
        return "Groups/add.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 39,  113 => 35,  106 => 30,  87 => 28,  82 => 27,  72 => 19,  53 => 17,  48 => 16,  37 => 9,  28 => 4,  22 => 2,  19 => 1,);
    }
}
