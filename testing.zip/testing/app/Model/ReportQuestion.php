<?php
App::uses('AppModel', 'Model');

/**
 * Subject Model
 *
 */

class ReportQuestion extends AppModel {
    public $useTable = 'report_question';
    /**
     * Validation rules
     * @var array
     */
/*    public $validate = array(
        'text' => array(
            'rule' => 'notEmpty',
            'message' => 'Имя вопроса не может быть пустым!'
        ),
        'answer_correct' => array(
            'rule' => 'notEmpty',
            'message' => 'Имя вопроса не может быть пустым!'
        ),

    );*/
}
