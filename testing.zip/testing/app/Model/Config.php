<?php
App::uses('AppModel', 'Model');

/**
 * Student Model
 *
 */

class Config extends AppModel {
    public $useTable = 'configs';
    /**
     * Validation rules
     * @var array
     */
/*    public $validate = array(
        'title' => array(
            'rule' => 'notEmpty',
            'message' => 'Имя факультета не может быть пустым!'
        ),

    );*/
}
